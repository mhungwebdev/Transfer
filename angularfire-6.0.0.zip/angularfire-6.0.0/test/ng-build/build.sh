cd ./test/ng-build/ng9 && yarn && npx ng build --prod
