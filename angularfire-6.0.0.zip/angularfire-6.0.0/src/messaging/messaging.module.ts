import { NgModule } from '@angular/core';
import { AngularFireMessaging } from './messaging';

@NgModule({
  providers: [ AngularFireMessaging ]
})
export class AngularFireMessagingModule { }
