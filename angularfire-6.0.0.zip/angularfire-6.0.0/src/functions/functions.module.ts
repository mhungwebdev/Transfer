import { NgModule } from '@angular/core';
import { AngularFireFunctions } from './functions';

@NgModule({
  providers: [ AngularFireFunctions ]
})
export class AngularFireFunctionsModule { }
