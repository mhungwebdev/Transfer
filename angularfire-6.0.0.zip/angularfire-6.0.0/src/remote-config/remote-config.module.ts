import { NgModule } from '@angular/core';
import { AngularFireRemoteConfig } from './remote-config';

@NgModule({
    providers: [AngularFireRemoteConfig]
})
export class AngularFireRemoteConfigModule { }
